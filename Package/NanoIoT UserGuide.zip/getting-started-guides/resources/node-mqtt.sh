# Assuming you have Node.js and NPM installed on your Windows/Linux/MacOS machine
npm install mqtt -g