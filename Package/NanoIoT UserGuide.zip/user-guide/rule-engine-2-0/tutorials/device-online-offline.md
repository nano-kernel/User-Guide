---
layout: docwithnav
title: Device Online/Offline events
description: Device Online/Offline events

---

**TODO - write**.