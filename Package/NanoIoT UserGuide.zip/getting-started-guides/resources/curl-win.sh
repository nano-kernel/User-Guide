NOTE: Starting Windows 10 b17063, cURL is available by default.
More info here: https://blogs.msdn.microsoft.com/commandline/2018/01/18/tar-and-curl-come-to-windows/
If you are using older version of Windows OS, you may find official installation guides here: https://curl.haxx.se/